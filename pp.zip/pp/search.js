let users = ['narcis', 'andrei', 'ion', 'costel', 'andreee'];
let div = document.querySelector('div');

function searchUser () {
    div.innerHTML = "";
    let usersLength = users.length;
    let inputHTML = document.getElementById("search");

    for (let i = 0; i < usersLength; ++i) {
        let name = users[i];
        console.log(name);

        if (inputHTML.value == name) {
            let newElement = document.createElement("h1");
            let textvalue = document.createTextNode(name);
            newElement.appendChild(textvalue);
            div.appendChild(newElement);
        }
    }
}